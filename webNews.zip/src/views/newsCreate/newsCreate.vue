<template>
    <div class="create">
        <el-form ref="form" :model="form" label-width="100px" class="create-form" :rules="rules">
            <el-form-item label="文章标题:" prop="title">
                <el-input v-model="form.title"></el-input>
            </el-form-item>
            <el-form-item label="文章分类:" prop="region" style="width: 80%">
                <!--<el-select v-model="form.region" placeholder="请选择文章类别" >-->
                <!--<el-option label="体育" value='sports'></el-option>-->
                <!--<el-option label="政治" value='political'></el-option>-->
                <!--<el-option label="娱乐" value='entertainment'></el-option>-->
                <!--<el-option label="文化" value='culture'></el-option>-->
                <!--</el-select>-->
                <el-select v-model="form.region" placeholder="请选择文章类别" style="width: 80%">
                    <el-option v-for="(re,index) in allRegion" :key=index :value="re.region" :label="re.region"
                               style="width: 70%"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="发布时间:" prop="time">
                <el-col :span="6">
                    <el-date-picker type="date" placeholder="选择日期" v-model="form.time"
                                    style="width:100%;"></el-date-picker>
                </el-col>
            </el-form-item>
            <el-form-item label="文章正文:" prop="desc">
                <el-input type="textarea" v-model="form.desc"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" class="form-button" style="margin-left: 38%;" @click="onSubmit($event)">发布新闻</el-button>
                <el-button class="form-button" @click="onClear">清除</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    import axios from 'axios'

    export default {
        data() {
            return {
                form: {
                    title: '',
                    region: '',
                    time: '',
                    desc: ''
                },
                rules: {
                    title: [
                        {required: true, message: '请输入文章标题', trigger: 'blur'},
                    ],
                    region: [
                        {required: true, message: '请选择文章栏目', trigger: 'blur'}
                    ],
                    time: [
                        {type: 'date', required: true, message: '请选择日期', trigger: 'blur'}
                    ],
                    desc: [
                        {required: true, message: '请填写文章正文', trigger: 'blur'}
                    ]
                }
            }
        },
        computed: {
            allRegion() {
                return this.$store.state.allRegion
            },
        },
        methods: {
            onSubmit(e) {
                e.preventDefault();
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        let formDate = new FormData();
                        let form = this.form;
                        let self = this;
                        formDate.append('title', form.title);
                        formDate.append('region', form.region);
                        formDate.append('time', form.time);
                        formDate.append('desc', form.desc);
                        let config = {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                        };
                        this.$post('/addinfo', formDate, config).then(function () {
                            self.onClear();
                            self.$message({
                                message: '已发送',
                                type: 'success',
                                center: true,
                                customClass: 'tip',
                                duration: 1500
                            })
                        }).catch((e) => console.log(e))
                    }
                    else {
                        return false;
                    }
                })
            },
            onClear() {
                this.form = {
                    title: '',
                    region: '',
                    time: '',
                    desc: ''
                }
            }
        },
        mounted() {
            this.$store.commit('changeTurnBlack')
        }
    }
</script>

<style lang="less" TYPE="text/less" scoped>
    .create {
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.07);
        padding-top: 70px;
        .el-input {
            width: 25%;
        }
        .form-button {
            float: left;
            display: block;
        }

        .tip {
            z-index: 0;
            position: absolute;
            top: 10%;
        }

        textarea {
            height: 200px;
            width: 90%;
        }
    }

    .create-form {
        width: 80%;
        height: 80%;
        margin: 20px auto 0 auto;
        border-radius: 10px;
        background-color: rgba(255, 255, 255, 0.8);
        box-shadow: 1px 1px 1px 1px #dddddd;
        padding: 50px 30px 20px 30px;
    }


</style>