<template>
    <div class="news-info">
        <div class="card-div">
            <el-card v-for="(one, index) in pageData" :key="index" class="card">
                <div class="card-title"><b>{{one.title}}</b></div>
                <div class="card-desc">{{one.desc}}</div>
                <div class="card-bottom">{{one.time}}</div>
            </el-card>
        </div>
        <div class="block">
            <el-pagination
                    @current-change="handleCurrentChange"
                    class="receive-propose-dueout-page"
                    background
                    layout="prev, pager, next"
                    :page-size=8
                    :total="length">
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                currentDate: new Date(),
                tableDataLength: 10
            }
        },
        computed: {
            length() {
                return this.$store.state.news.length
            },
            pageData() {
                return this.$store.state.pageNews
            }
        },
        methods: {
            //进行换页操作
            handleCurrentChange(e) {
                this.$store.commit('changePageNews', e);
            },
        },
        mounted() {
            this.$store.commit('getNowNews')
            this.$store.commit('changeTurnBlack')

        }
    }
</script>

<style lang="less" TYPE="text/less" >
    .news-info {
        width: 100%;
        height: 100%;
        color: #768399;
        background-color: rgba(0, 0, 0, 0.07);
        padding-top: 50px;
        .card-div {
            float: left;
            width: 80%;
            height: 90%;
            overflow: auto;
            margin-left: 10%;
            margin-top: 20px;
            padding: 10px;
        }

        .card {
            width: 20%;
            float: left;
            margin-left: 2.5%;
            margin-right: 2.5%;
            height: 45%;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }

        .card-desc {
            height: 70%;
            padding: 10px;
            text-align: left;
            display: block;
            overflow-y: auto;
        }
        .el-card__body{
            height: 100%!important;
            padding: 10px;
        }

        .card-title {
            padding-bottom: 10px;
            margin-bottom: 5px;
            height: 15%;
            display: block;
        }

        .card-bottom {
            padding-top: 10px;
            font-size: 13px;
            color: #999;
            height: 8%;
            font-weight: 500;
            display: block;
        }

        .block {
            clear: both;
            width: 5%;
            margin: 0 auto 0 auto;
            padding: 0 auto;
            text-align: center;
        }
    }



</style>