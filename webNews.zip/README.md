update to webpack4  
use eslint   
use postcss  
